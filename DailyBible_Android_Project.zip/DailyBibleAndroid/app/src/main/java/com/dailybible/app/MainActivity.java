package com.dailybible.app;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import org.json.JSONObject;

public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    private WebView web;
    private boolean gate;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF0B0A09);
        getWindow().setNavigationBarColor(0xFF0B0A09);
        gate = getIntent().getBooleanExtra("gate", false);
        web = new WebView(this);
        web.setBackgroundColor(0xFF0B0A09);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String p = u.getPath();
                if (p == null || p.equals("/")) p = "/index.html";
                try {
                    InputStream in = getAssets().open(p.substring(1));
                    return new WebResourceResponse(p.endsWith(".html") ? "text/html" : "application/octet-stream", "utf-8", in);
                } catch (Exception e) {
                    return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (HOST.equals(r.getUrl().getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception e) { }
                return true;
            }
            @Override public void onPageFinished(WebView v, String url) {
                if (gate) v.evaluateJavascript("window.showGate&&showGate()", null);
            }
        });
        Util.schedule(this);
        web.loadUrl("https://" + HOST + "/index.html");
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        gate = i.getBooleanExtra("gate", false);
        web.evaluateJavascript(gate ? "window.showGate&&showGate()" : "window.hideGate&&hideGate()", null);
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("(function(){var g=document.getElementById('gt');if(g&&g.style.display==='flex')return 2;"
                + "var b=document.getElementById('back');if(b&&!b.hidden){b.click();return 1}return 0})()",
                new ValueCallback<String>() {
                    @Override public void onReceiveValue(String r) {
                        if ("0".equals(r)) moveTaskToBack(true);
                        else if ("2".equals(r)) goHome();
                    }
                });
    }

    private void goHome() {
        Intent h = new Intent(Intent.ACTION_MAIN);
        h.addCategory(Intent.CATEGORY_HOME);
        h.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(h);
    }

    private Uri saveImage(String dataUrl) {
        try {
            byte[] d = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "verse_" + System.currentTimeMillis() + ".png");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DailyBible");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (u == null) return null;
            OutputStream o = getContentResolver().openOutputStream(u);
            o.write(d);
            o.close();
            return u;
        } catch (Exception e) { return null; }
    }

    private void toast(final String m) {
        runOnUiThread(new Runnable() { @Override public void run() { Toast.makeText(MainActivity.this, m, Toast.LENGTH_SHORT).show(); } });
    }

    private void open(final Intent i) {
        runOnUiThread(new Runnable() { @Override public void run() { try { startActivity(i); } catch (Exception e) { } } });
    }

    private class Bridge {
        @JavascriptInterface public void markRead() { Util.sp(MainActivity.this).edit().putLong("read", Util.day()).apply(); }

        @JavascriptInterface public void finishGate() {
            runOnUiThread(new Runnable() { @Override public void run() { gate = false; moveTaskToBack(true); } });
        }

        @JavascriptInterface public String status() {
            try {
                SharedPreferences sp = Util.sp(MainActivity.this);
                JSONObject o = new JSONObject();
                o.put("read", sp.getLong("read", -1) == Util.day());
                o.put("lock", sp.getBoolean("lock", false));
                o.put("rem", sp.getBoolean("rem", false));
                o.put("h", sp.getInt("h", 7));
                o.put("m", sp.getInt("m", 0));
                Set<String> bl = sp.getStringSet("blocked", null);
                o.put("n", bl == null ? 0 : bl.size());
                o.put("a11y", Util.a11yOn(MainActivity.this));
                o.put("ovl", Settings.canDrawOverlays(MainActivity.this));
                o.put("ntf", ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).areNotificationsEnabled());
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }

        @JavascriptInterface public void setReminder(boolean on, int h, int m) {
            Util.sp(MainActivity.this).edit().putBoolean("rem", on).putInt("h", h).putInt("m", m).apply();
            Util.schedule(MainActivity.this);
        }

        @JavascriptInterface public void setLock(boolean on) { Util.sp(MainActivity.this).edit().putBoolean("lock", on).apply(); }

        @JavascriptInterface public void setVerses(String json) { Util.sp(MainActivity.this).edit().putString("verses", json).apply(); }

        @JavascriptInterface public void pickApps() { open(new Intent(MainActivity.this, AppPickerActivity.class)); }

        @JavascriptInterface public void openAccessibility() { open(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }

        @JavascriptInterface public void openOverlay() {
            open(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        }

        @JavascriptInterface public void askNotif() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
                    else startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
                }
            });
        }

        @JavascriptInterface public void saveImage(String dataUrl) {
            toast(MainActivity.this.saveImage(dataUrl) != null ? "Saved to Pictures/DailyBible" : "Could not save");
        }

        @JavascriptInterface public void shareImage(String dataUrl) {
            Uri u = MainActivity.this.saveImage(dataUrl);
            if (u == null) { toast("Could not share"); return; }
            Intent s = new Intent(Intent.ACTION_SEND);
            s.setType("image/png");
            s.putExtra(Intent.EXTRA_STREAM, u);
            s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            open(Intent.createChooser(s, "Share verse"));
        }
    }
}
