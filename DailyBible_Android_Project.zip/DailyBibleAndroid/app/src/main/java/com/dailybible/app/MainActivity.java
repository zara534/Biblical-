package com.dailybible.app;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import org.json.JSONObject;

public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    private WebView web;
    private String go;
    private ImageView splash;
    private boolean splashGone;
    private long splashStart;
    private final Handler ui = new Handler();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        applyBars();
        go = getIntent().getStringExtra("go");
        web = new WebView(this);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF030201);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        {
            splash = new ImageView(this);
            splash.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            splash.setBackgroundColor(0xFF030201);
            root.addView(splash, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            splashStart = SystemClock.uptimeMillis();
            ui.postDelayed(new Runnable() { @Override public void run() { hideSplash(); } }, 5000);
        }
        setContentView(root);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);   // stops the whole app stretching or shifting when you swipe
        WebSettings s = web.getSettings();
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        if (Build.VERSION.SDK_INT >= 33) s.setAlgorithmicDarkeningAllowed(false);
        else s.setForceDark(WebSettings.FORCE_DARK_OFF);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String p = u.getPath();
                if (p == null || p.equals("/")) p = "/index.html";
                try {
                    InputStream in = getAssets().open(p.substring(1));
                    return new WebResourceResponse(p.endsWith(".html") ? "text/html" : "application/octet-stream", "utf-8", in);
                } catch (Exception e) {
                    return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (HOST.equals(r.getUrl().getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception e) { }
                return true;
            }
            @Override public void onPageFinished(WebView v, String url) {
                if (go != null) { v.evaluateJavascript("window.goTo&&goTo('" + go + "')", null); go = null; }
                long wait = Math.max(0, 250 - (SystemClock.uptimeMillis() - splashStart));
                ui.postDelayed(new Runnable() { @Override public void run() { hideSplash(); } }, wait);
            }
        });
        Util.schedule(this);
        web.loadUrl("https://" + HOST + "/index.html");
    }

    @Override protected void onResume() {
        super.onResume();
        try { Util.schedule(this); } catch (Exception e) { }
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        String g = i.getStringExtra("go");
        if (g != null) web.evaluateJavascript("window.goTo&&goTo('" + g + "')", null);
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("(function(){var b=document.getElementById('back');if(b&&!b.hidden){b.click();return 1}return 0})()",
                new ValueCallback<String>() {
                    @Override public void onReceiveValue(String r) { if ("0".equals(r)) moveTaskToBack(true); }
                });
    }

    private void hideSplash() {
        if (splash == null || splashGone) return;
        splashGone = true;
        splash.animate().alpha(0f).setDuration(450).withEndAction(new Runnable() {
            @Override public void run() {
                ((ViewGroup) splash.getParent()).removeView(splash);
                splash = null;
            }
        }).start();
    }

    private void applyBars() {
        getWindow().setStatusBarColor(0xFF0B0A09);
        getWindow().setNavigationBarColor(0xFF0B0A09);
        if (web != null) web.setBackgroundColor(0xFF0B0A09);
    }

    private Uri saveImage(String dataUrl) {
        try {
            byte[] d = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "verse_" + System.currentTimeMillis() + ".png");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/HolySteps");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (u == null) return null;
            OutputStream o = getContentResolver().openOutputStream(u);
            o.write(d);
            o.close();
            return u;
        } catch (Exception e) { return null; }
    }

    private void toast(final String m) {
        runOnUiThread(new Runnable() { @Override public void run() { Toast.makeText(MainActivity.this, m, Toast.LENGTH_SHORT).show(); } });
    }

    private void open(final Intent i) {
        runOnUiThread(new Runnable() { @Override public void run() { try { startActivity(i); } catch (Exception e) { } } });
    }

    private class Bridge {
        @JavascriptInterface public void markRead() {
            Util.sp(MainActivity.this).edit().putLong("read", Util.day()).apply();
            Util.finish(MainActivity.this, "verse");
            Util.finish(MainActivity.this, "streak");
        }

        // Remembers which tasks are done today, so reminders for them can skip the day.
        @JavascriptInterface public void setDone(String json) {
            try {
                org.json.JSONArray a = new org.json.JSONArray(json);
                java.util.HashSet<String> d = new java.util.HashSet<>();
                for (int i = 0; i < a.length(); i++) d.add(a.getString(i));
                Util.sp(MainActivity.this).edit().putStringSet("done", d).putLong("done_day", Util.day()).apply();
                for (String id : d) if (Util.idx(id) >= 0) Util.finish(MainActivity.this, id);
            } catch (Exception e) { }
        }

        @JavascriptInterface public void setPlan(String text) { Util.sp(MainActivity.this).edit().putString("planText", text).apply(); }

        @JavascriptInterface public String status() {
            try {
                SharedPreferences sp = Util.sp(MainActivity.this);
                JSONObject o = new JSONObject();
                o.put("read", sp.getLong("read", -1) == Util.day());
                JSONObject r = new JSONObject();
                for (int i = 0; i < Util.IDS.length; i++) {
                    JSONObject x = new JSONObject();
                    x.put("on", Util.on(MainActivity.this, Util.IDS[i]));
                    x.put("h", Util.hour(MainActivity.this, i));
                    x.put("m", Util.min(MainActivity.this, i));
                    x.put("a", Util.alarm(MainActivity.this, Util.IDS[i]));
                    x.put("d", Util.days(MainActivity.this, i));
                    r.put(Util.IDS[i], x);
                }
                o.put("r", r);
                o.put("fast", sp.getBoolean("fast_on", true));
                o.put("fa", Util.alarm(MainActivity.this, "fast"));
                o.put("ntf", ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).areNotificationsEnabled());
                o.put("nag", sp.getBoolean("nag_on", true));
                o.put("exact", Util.canExact(MainActivity.this));
                o.put("batt", ((PowerManager) getSystemService(POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName()));
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }

        @JavascriptInterface public void setReminder(String id, boolean on, int h, int m) {
            Util.sp(MainActivity.this).edit().putBoolean("r_" + id + "_on", on).putInt("r_" + id + "_h", h).putInt("r_" + id + "_m", m).apply();
            for (int i = 0; i < Util.IDS.length; i++) if (Util.IDS[i].equals(id)) {
                if (on) Util.noteSetup(MainActivity.this, i); else Util.cancelFollowUp(MainActivity.this, id);
                Util.scheduleOne(MainActivity.this, i);
            }
        }

        @JavascriptInterface public void setDays(String id, int mask) {
            int i = Util.idx(id);
            if (i < 0) return;
            Util.sp(MainActivity.this).edit().putInt("r_" + id + "_d", mask == 0 ? 127 : mask).apply();
            Util.scheduleOne(MainActivity.this, i);
        }

        @JavascriptInterface public void setStyle(String id, boolean alarm) {
            Util.sp(MainActivity.this).edit().putBoolean(id.equals("fast") ? "fast_alarm" : "r_" + id + "_alarm", alarm).apply();
            Util.schedule(MainActivity.this);
        }

        @JavascriptInterface public void testAlarm() {
            ReminderReceiver.show(MainActivity.this, "Holy Steps", "This is how an alarm reminder sounds.", "home", 98, true, "test");
        }

        @JavascriptInterface public void setFast(boolean on) {
            Util.sp(MainActivity.this).edit().putBoolean("fast_on", on).apply();
            Util.scheduleFast(MainActivity.this);
        }

        @JavascriptInterface public void setFastEnd(long end) {
            Util.sp(MainActivity.this).edit().putLong("fastEnd", end).apply();
            Util.scheduleFast(MainActivity.this);
        }

        @JavascriptInterface public void setNag(boolean on) {
            Util.sp(MainActivity.this).edit().putBoolean("nag_on", on).apply();
            if (!on) Util.cancelNags(MainActivity.this);
        }

        // Lets reminders arrive on the minute (only needed on Android 12 and 12L, newer versions allow it automatically).
        @JavascriptInterface public void openExact() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try {
                        if (Build.VERSION.SDK_INT >= 31)
                            startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName())));
                    } catch (Exception e) { }
                }
            });
        }

        // Asks Android not to delay or stop this app's reminders to save battery.
        @JavascriptInterface public void askBattery() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try {
                        startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
                    } catch (Exception e) {
                        try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } catch (Exception e2) { }
                    }
                }
            });
        }

        @JavascriptInterface public void setVerses(String json) { Util.sp(MainActivity.this).edit().putString("verses", json).apply(); VerseWidget.refresh(MainActivity.this); }

        @JavascriptInterface public void askNotif() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
                    else startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
                }
            });
        }

        @JavascriptInterface public void saveImage(String dataUrl) {
            toast(MainActivity.this.saveImage(dataUrl) != null ? "Saved to Pictures/HolySteps" : "Could not save");
        }

        @JavascriptInterface public void shareImage(String dataUrl) {
            Uri u = MainActivity.this.saveImage(dataUrl);
            if (u == null) { toast("Could not share"); return; }
            Intent s = new Intent(Intent.ACTION_SEND);
            s.setType("image/png");
            s.putExtra(Intent.EXTRA_STREAM, u);
            s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            open(Intent.createChooser(s, "Share verse"));
        }
    }
}
