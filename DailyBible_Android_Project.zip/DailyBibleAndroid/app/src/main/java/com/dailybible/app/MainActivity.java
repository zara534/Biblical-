package com.dailybible.app;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;
import android.os.Handler;
import android.os.SystemClock;
import android.view.ViewGroup;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import org.json.JSONObject;

public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    private WebView web;
    private boolean gate;
    private String go;
    private ImageView splash;
    private boolean splashGone;
    private long splashStart;
    private final Handler ui = new Handler();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        applyBars(Util.sp(this).getBoolean("light", false));
        gate = getIntent().getBooleanExtra("gate", false);
        go = getIntent().getStringExtra("go");
        web = new WebView(this);
        applyBars(Util.sp(this).getBoolean("light", false));
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF030201);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (!gate) {
            splash = new ImageView(this);
            splash.setImageResource(R.drawable.splash);
            splash.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            splash.setBackgroundColor(0xFF030201);
            root.addView(splash, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            splashStart = SystemClock.uptimeMillis();
            ui.postDelayed(new Runnable() { @Override public void run() { hideSplash(); } }, 5000);
        }
        setContentView(root);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        // Stop Android from auto-darkening the page, so our own light theme shows properly.
        if (Build.VERSION.SDK_INT >= 33) s.setAlgorithmicDarkeningAllowed(false);
        else s.setForceDark(WebSettings.FORCE_DARK_OFF);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String p = u.getPath();
                if (p == null || p.equals("/")) p = "/index.html";
                try {
                    InputStream in = getAssets().open(p.substring(1));
                    return new WebResourceResponse(p.endsWith(".html") ? "text/html" : "application/octet-stream", "utf-8", in);
                } catch (Exception e) {
                    return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (HOST.equals(r.getUrl().getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception e) { }
                return true;
            }
            @Override public void onPageFinished(WebView v, String url) {
                if (gate) v.evaluateJavascript("window.showGate&&showGate()", null);
                if (go != null) { v.evaluateJavascript("window.goTo&&goTo('" + go + "')", null); go = null; }
                long wait = Math.max(0, 1500 - (SystemClock.uptimeMillis() - splashStart));
                ui.postDelayed(new Runnable() { @Override public void run() { hideSplash(); } }, wait);
            }
        });
        Util.schedule(this);
        web.loadUrl("https://" + HOST + "/index.html");
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        gate = i.getBooleanExtra("gate", false);
        web.evaluateJavascript(gate ? "window.showGate&&showGate()" : "window.hideGate&&hideGate()", null);
        String g = i.getStringExtra("go");
        if (g != null) web.evaluateJavascript("window.goTo&&goTo('" + g + "')", null);
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("(function(){var g=document.getElementById('gt');if(g&&g.style.display==='flex')return 2;"
                + "var b=document.getElementById('back');if(b&&!b.hidden){b.click();return 1}return 0})()",
                new ValueCallback<String>() {
                    @Override public void onReceiveValue(String r) {
                        if ("0".equals(r)) moveTaskToBack(true);
                        else if ("2".equals(r)) goHome();
                    }
                });
    }

    private void hideSplash() {
        if (splash == null || splashGone) return;
        splashGone = true;
        splash.animate().alpha(0f).setDuration(450).withEndAction(new Runnable() {
            @Override public void run() {
                ((ViewGroup) splash.getParent()).removeView(splash);
                splash = null;
            }
        }).start();
    }

    private void applyBars(boolean light) {
        int c = light ? 0xFFFAF6EE : 0xFF0B0A09;
        getWindow().setStatusBarColor(c);
        getWindow().setNavigationBarColor(c);
        if (web != null) web.setBackgroundColor(c);
        getWindow().getDecorView().setSystemUiVisibility(light
                ? (android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR) : 0);
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (web != null) web.evaluateJavascript("window.applyPrefs&&applyPrefs()", null);
    }

    private void goHome() {
        Intent h = new Intent(Intent.ACTION_MAIN);
        h.addCategory(Intent.CATEGORY_HOME);
        h.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(h);
    }

    private Uri saveImage(String dataUrl) {
        try {
            byte[] d = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "verse_" + System.currentTimeMillis() + ".png");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/HolySteps");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (u == null) return null;
            OutputStream o = getContentResolver().openOutputStream(u);
            o.write(d);
            o.close();
            return u;
        } catch (Exception e) { return null; }
    }

    private void toast(final String m) {
        runOnUiThread(new Runnable() { @Override public void run() { Toast.makeText(MainActivity.this, m, Toast.LENGTH_SHORT).show(); } });
    }

    private void open(final Intent i) {
        runOnUiThread(new Runnable() { @Override public void run() { try { startActivity(i); } catch (Exception e) { } } });
    }

    private class Bridge {
        @JavascriptInterface public boolean systemDark() {
            return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        }

        @JavascriptInterface public void setTheme(final boolean light) {
            Util.sp(MainActivity.this).edit().putBoolean("light", light).apply();
            runOnUiThread(new Runnable() { @Override public void run() { applyBars(light); } });
        }

        // Returns true when this was the last thing needed to unlock your apps.
        @JavascriptInterface public boolean markRead() {
            boolean was = Util.unlocked(MainActivity.this);
            Util.sp(MainActivity.this).edit().putLong("read", Util.day()).apply();
            return !was && Util.unlocked(MainActivity.this) && Util.sp(MainActivity.this).getBoolean("lock", false);
        }

        @JavascriptInterface public boolean setDone(String json) {
            boolean was = Util.unlocked(MainActivity.this);
            try {
                org.json.JSONArray a = new org.json.JSONArray(json);
                java.util.HashSet<String> d = new java.util.HashSet<>();
                for (int i = 0; i < a.length(); i++) d.add(a.getString(i));
                Util.sp(MainActivity.this).edit().putStringSet("done", d).putLong("done_day", Util.day()).apply();
            } catch (Exception e) { }
            return !was && Util.unlocked(MainActivity.this) && Util.sp(MainActivity.this).getBoolean("lock", false);
        }

        @JavascriptInterface public void setPlan(String text) { Util.sp(MainActivity.this).edit().putString("planText", text).apply(); }

        @JavascriptInterface public void setReq(String id, boolean on) {
            java.util.Set<String> r = Util.req(MainActivity.this);
            if (on) r.add(id); else r.remove(id);
            if (r.isEmpty()) return;   // keep at least one requirement
            Util.sp(MainActivity.this).edit().putStringSet("req", new java.util.HashSet<String>(r)).apply();
        }


        @JavascriptInterface public void finishGate() {
            runOnUiThread(new Runnable() { @Override public void run() { gate = false; moveTaskToBack(true); } });
        }

        @JavascriptInterface public String status() {
            try {
                SharedPreferences sp = Util.sp(MainActivity.this);
                JSONObject o = new JSONObject();
                o.put("read", sp.getLong("read", -1) == Util.day());
                o.put("lock", sp.getBoolean("lock", false));
                JSONObject r = new JSONObject();
                for (int i = 0; i < Util.IDS.length; i++) {
                    JSONObject x = new JSONObject();
                    x.put("on", Util.on(MainActivity.this, Util.IDS[i]));
                    x.put("h", Util.hour(MainActivity.this, i));
                    x.put("m", Util.min(MainActivity.this, i));
                    x.put("a", Util.alarm(MainActivity.this, Util.IDS[i]));
                    r.put(Util.IDS[i], x);
                }
                o.put("r", r);
                o.put("fast", sp.getBoolean("fast_on", true));
                o.put("fa", Util.alarm(MainActivity.this, "fast"));
                org.json.JSONArray rq = new org.json.JSONArray(), dn = new org.json.JSONArray();
                for (String t : Util.TASKS) {
                    if (Util.req(MainActivity.this).contains(t)) rq.put(t);
                    if (Util.done(MainActivity.this, t)) dn.put(t);
                }
                o.put("req", rq);
                o.put("done", dn);
                Set<String> bl = sp.getStringSet("blocked", null);
                o.put("n", bl == null ? 0 : bl.size());
                o.put("a11y", Util.a11yOn(MainActivity.this));
                o.put("ovl", Settings.canDrawOverlays(MainActivity.this));
                o.put("ntf", ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).areNotificationsEnabled());
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }

        @JavascriptInterface public void setReminder(String id, boolean on, int h, int m) {
            Util.sp(MainActivity.this).edit().putBoolean("r_" + id + "_on", on).putInt("r_" + id + "_h", h).putInt("r_" + id + "_m", m).apply();
            for (int i = 0; i < Util.IDS.length; i++) if (Util.IDS[i].equals(id)) Util.scheduleOne(MainActivity.this, i);
        }

        @JavascriptInterface public void setStyle(String id, boolean alarm) {
            Util.sp(MainActivity.this).edit().putBoolean(id.equals("fast") ? "fast_alarm" : "r_" + id + "_alarm", alarm).apply();
        }

        @JavascriptInterface public void testAlarm() {
            ReminderReceiver.show(MainActivity.this, "Holy Steps", "This is how an alarm reminder sounds.", "home", 98, true, "verse");
        }

        @JavascriptInterface public void setFast(boolean on) {
            Util.sp(MainActivity.this).edit().putBoolean("fast_on", on).apply();
            Util.scheduleFast(MainActivity.this);
        }

        @JavascriptInterface public void setFastEnd(long end) {
            Util.sp(MainActivity.this).edit().putLong("fastEnd", end).apply();
            Util.scheduleFast(MainActivity.this);
        }

        @JavascriptInterface public void setLock(boolean on) { Util.sp(MainActivity.this).edit().putBoolean("lock", on).apply(); }

        @JavascriptInterface public void setVerses(String json) { Util.sp(MainActivity.this).edit().putString("verses", json).apply(); }

        @JavascriptInterface public void pickApps() { open(new Intent(MainActivity.this, AppPickerActivity.class)); }

        @JavascriptInterface public void openAccessibility() { open(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }

        @JavascriptInterface public void openOverlay() {
            open(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        }

        @JavascriptInterface public void askNotif() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
                    else startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
                }
            });
        }

        @JavascriptInterface public void saveImage(String dataUrl) {
            toast(MainActivity.this.saveImage(dataUrl) != null ? "Saved to Pictures/HolySteps" : "Could not save");
        }

        @JavascriptInterface public void shareImage(String dataUrl) {
            Uri u = MainActivity.this.saveImage(dataUrl);
            if (u == null) { toast("Could not share"); return; }
            Intent s = new Intent(Intent.ACTION_SEND);
            s.setType("image/png");
            s.putExtra(Intent.EXTRA_STREAM, u);
            s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            open(Intent.createChooser(s, "Share verse"));
        }
    }
}
