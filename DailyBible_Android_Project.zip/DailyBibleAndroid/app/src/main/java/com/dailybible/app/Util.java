package com.dailybible.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.provider.Settings;
import java.util.Calendar;
import java.util.TimeZone;

final class Util {
    static SharedPreferences sp(Context c) { return c.getSharedPreferences("db", Context.MODE_PRIVATE); }

    // Same day number the web app uses: whole days since 1970 in local time.
    static long day() {
        long n = System.currentTimeMillis();
        return (n + TimeZone.getDefault().getOffset(n)) / 86400000L;
    }

    static boolean a11yOn(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return s != null && s.contains(c.getPackageName()) && s.contains("BlockService");
    }

    static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(c, ReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(c, 1, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        SharedPreferences s = sp(c);
        if (!s.getBoolean("rem", false)) { am.cancel(pi); return; }
        Calendar t = Calendar.getInstance();
        t.set(Calendar.HOUR_OF_DAY, s.getInt("h", 7));
        t.set(Calendar.MINUTE, s.getInt("m", 0));
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        if (t.getTimeInMillis() <= System.currentTimeMillis() + 1000) t.add(Calendar.DAY_OF_MONTH, 1);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.getTimeInMillis(), pi);
    }
}
