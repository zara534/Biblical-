package com.dailybible.app;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import java.util.Calendar;
import java.util.Set;
import java.util.TimeZone;

final class Util {
    // Reminder ids and their default hour. Minutes default to 0.
    static final String[] IDS = {"verse", "plan", "prayer", "memory", "streak", "reflect"};
    static final int[] DH = {7, 8, 12, 18, 20, 21};
    // Ids that can have a snooze or repeat waiting (the fast alert can be snoozed too).
    static final String[] FU_IDS = {"verse", "plan", "prayer", "memory", "streak", "reflect", "fast"};

    // What a reminder broadcast means.
    static final int M_DAILY = 0;    // the normal scheduled time
    static final int M_SNOOZE = 1;   // you tapped Snooze
    static final int M_AGAIN = 2;    // a snooze finished, ring again
    static final int M_NAG = 4;      // keep-reminding repeat

    static final long NAG_MS = 30 * 60000L;
    static final long SNOOZE_MS = 10 * 60000L;
    static final long CATCH_UP_MS = 3 * 3600000L;

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("db", Context.MODE_PRIVATE); }

    // Same day number the web app uses: whole days since 1970 in local time.
    static long day() {
        long n = System.currentTimeMillis();
        return (n + TimeZone.getDefault().getOffset(n)) / 86400000L;
    }

    // Has this task been done today? (The verse is tracked separately, the rest are synced from the web app.)
    static boolean done(Context c, String id) {
        SharedPreferences s = sp(c);
        if (id.equals("verse")) return s.getLong("read", -1) == day();
        if (s.getLong("done_day", -1) != day()) return false;
        Set<String> d = s.getStringSet("done", null);
        return d != null && d.contains(id);
    }

    static boolean on(Context c, String id) { return sp(c).getBoolean("r_" + id + "_on", false); }
    static int hour(Context c, int i) { return sp(c).getInt("r_" + IDS[i] + "_h", DH[i]); }
    static int min(Context c, int i) { return sp(c).getInt("r_" + IDS[i] + "_m", 0); }

    static int idx(String id) {
        for (int i = 0; i < IDS.length; i++) if (IDS[i].equals(id)) return i;
        return -1;
    }

    // Notification id for a reminder. Fast = 99, anything else (the test alarm) = 98.
    static int nid(String id) {
        int i = idx(id);
        if (i >= 0) return 10 + i;
        return id.equals("fast") ? 99 : 98;
    }

    static PendingIntent pi(Context c, int code, String id) { return pi(c, code, id, M_DAILY); }

    static PendingIntent pi(Context c, int code, String id, int mode) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.putExtra("id", id);
        i.putExtra("mode", mode);
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static boolean alarm(Context c, String id) {
        return sp(c).getBoolean(id.equals("fast") ? "fast_alarm" : "r_" + id + "_alarm", false);
    }

    static AlarmManager am(Context c) { return (AlarmManager) c.getSystemService(Context.ALARM_SERVICE); }

    static boolean canExact(Context c) {
        return Build.VERSION.SDK_INT < 31 || am(c).canScheduleExactAlarms();
    }

    // Sets one alarm as reliably as Android allows.
    // Alarm-style reminders use an alarm-clock alarm (never delayed by Doze or battery saver).
    // The rest use an exact alarm that also fires in Doze. If exact alarms are not allowed, it falls back to the best inexact one.
    static void fire(Context c, long at, PendingIntent p, boolean clock) {
        AlarmManager a = am(c);
        try {
            if (clock) {
                PendingIntent show = PendingIntent.getActivity(c, 7, new Intent(c, MainActivity.class),
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                a.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), p);
                return;
            }
            if (canExact(c)) { a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p); return; }
        } catch (SecurityException e) { }
        a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p);
    }

    static long timeToday(Context c, int i) {
        Calendar t = Calendar.getInstance();
        t.set(Calendar.HOUR_OF_DAY, hour(c, i));
        t.set(Calendar.MINUTE, min(c, i));
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        return t.getTimeInMillis();
    }

    static void scheduleOne(Context c, int i) {
        PendingIntent p = pi(c, 10 + i, IDS[i]);
        if (!on(c, IDS[i])) { am(c).cancel(p); return; }
        long t = timeToday(c, i);
        if (t <= System.currentTimeMillis() + 1000) {
            Calendar n = Calendar.getInstance();
            n.setTimeInMillis(t);
            n.add(Calendar.DAY_OF_MONTH, 1);
            t = n.getTimeInMillis();
        }
        fire(c, t, p, alarm(c, IDS[i]));
    }

    // Called when a reminder is switched on, so today's already-passed time is not treated as missed.
    static void noteSetup(Context c, int i) {
        if (on(c, IDS[i]) && timeToday(c, i) <= System.currentTimeMillis())
            sp(c).edit().putLong("last_" + IDS[i], day()).apply();
    }

    static void scheduleFast(Context c) {
        PendingIntent p = pi(c, 99, "fast");
        SharedPreferences s = sp(c);
        long e = s.getLong("fastEnd", 0);
        if (!s.getBoolean("fast_on", true) || e <= System.currentTimeMillis()) { am(c).cancel(p); return; }
        fire(c, e, p, alarm(c, "fast"));
    }

    // One snooze or keep-reminding repeat can wait per reminder. It is saved, so it survives a restart.
    static void followUp(Context c, String id, int mode, long at) {
        sp(c).edit().putLong("fu_" + id + "_t", at).putInt("fu_" + id + "_m", mode).apply();
        fire(c, at, pi(c, 200 + nid(id), id, mode), alarm(c, id));
    }

    static void clearFollowUp(Context c, String id) {
        sp(c).edit().remove("fu_" + id + "_t").remove("fu_" + id + "_m").apply();
    }

    static void cancelFollowUp(Context c, String id) {
        clearFollowUp(c, id);
        am(c).cancel(pi(c, 200 + nid(id), id, M_AGAIN));
    }

    // Only the keep-reminding repeats, snoozes stay.
    static void cancelNags(Context c) {
        SharedPreferences s = sp(c);
        for (String id : FU_IDS)
            if (s.getLong("fu_" + id + "_t", 0) != 0 && s.getInt("fu_" + id + "_m", M_AGAIN) == M_NAG) cancelFollowUp(c, id);
    }

    // The task is done: remove its notification and any waiting snooze or repeat.
    static void finish(Context c, String id) {
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(nid(id));
        cancelFollowUp(c, id);
    }

    static void restoreFollowUps(Context c) {
        SharedPreferences s = sp(c);
        long now = System.currentTimeMillis();
        for (String id : FU_IDS) {
            long t = s.getLong("fu_" + id + "_t", 0);
            if (t == 0) continue;
            int m = s.getInt("fu_" + id + "_m", M_AGAIN);
            if (t > now) fire(c, t, pi(c, 200 + nid(id), id, m), alarm(c, id));
            else if (now - t < CATCH_UP_MS) fire(c, now + 3000, pi(c, 200 + nid(id), id, m), alarm(c, id)); // phone was off, ring soon
            else cancelFollowUp(c, id);
        }
    }

    // After a restart: a reminder whose time passed while the phone was off (within 3 hours) rings now.
    static void catchUp(Context c) {
        SharedPreferences s = sp(c);
        long now = System.currentTimeMillis();
        for (int i = 0; i < IDS.length; i++) {
            if (!on(c, IDS[i]) || s.getLong("last_" + IDS[i], -1) == day()) continue;
            long t = timeToday(c, i);
            if (t <= now && now - t < CATCH_UP_MS) fire(c, now + 4000, pi(c, 10 + i, IDS[i]), alarm(c, IDS[i]));
        }
    }

    static void schedule(Context c) { schedule(c, false); }

    static void schedule(Context c, boolean catchUp) {
        for (int i = 0; i < IDS.length; i++) scheduleOne(c, i);
        scheduleFast(c);
        restoreFollowUps(c);
        VerseWidget.refresh(c);
        if (catchUp) catchUp(c);
    }
}
