package com.dailybible.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.provider.Settings;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;
import java.util.TimeZone;

final class Util {
    // Reminder ids and their default hour. Minutes default to 0.
    static final String[] IDS = {"verse", "plan", "prayer", "memory", "streak", "reflect"};
    static final int[] DH = {7, 8, 12, 18, 20, 21};
    // Tasks that can be required to unlock your locked apps.
    static final String[] TASKS = {"verse", "plan", "prayer", "memory", "challenge", "reflect"};

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("db", Context.MODE_PRIVATE); }

    // Same day number the web app uses: whole days since 1970 in local time.
    static long day() {
        long n = System.currentTimeMillis();
        return (n + TimeZone.getDefault().getOffset(n)) / 86400000L;
    }

    static boolean a11yOn(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return s != null && s.contains(c.getPackageName()) && s.contains("BlockService");
    }

    // Has this task been done today? (The verse is tracked separately, the rest are synced from the web app.)
    static boolean done(Context c, String id) {
        SharedPreferences s = sp(c);
        if (id.equals("verse")) return s.getLong("read", -1) == day();
        if (s.getLong("done_day", -1) != day()) return false;
        Set<String> d = s.getStringSet("done", null);
        return d != null && d.contains(id);
    }

    static Set<String> req(Context c) {
        Set<String> r = new HashSet<>();
        Set<String> saved = sp(c).getStringSet("req", null);
        if (saved != null) r.addAll(saved);
        if (r.isEmpty()) r.add("verse");
        return r;
    }

    static boolean unlocked(Context c) {
        for (String id : req(c)) if (!done(c, id)) return false;
        return true;
    }

    static boolean on(Context c, String id) { return sp(c).getBoolean("r_" + id + "_on", false); }
    static int hour(Context c, int i) { return sp(c).getInt("r_" + IDS[i] + "_h", DH[i]); }
    static int min(Context c, int i) { return sp(c).getInt("r_" + IDS[i] + "_m", 0); }

    static PendingIntent pi(Context c, int code, String id) { return pi(c, code, id, false, false); }

    static PendingIntent pi(Context c, int code, String id, boolean once, boolean snooze) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.putExtra("id", id);
        i.putExtra("once", once);
        i.putExtra("snooze", snooze);
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static boolean alarm(Context c, String id) {
        return sp(c).getBoolean(id.equals("fast") ? "fast_alarm" : "r_" + id + "_alarm", false);
    }

    static void scheduleOne(Context c, int i) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent p = pi(c, 10 + i, IDS[i]);
        if (!on(c, IDS[i])) { am.cancel(p); return; }
        Calendar t = Calendar.getInstance();
        t.set(Calendar.HOUR_OF_DAY, hour(c, i));
        t.set(Calendar.MINUTE, min(c, i));
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        if (t.getTimeInMillis() <= System.currentTimeMillis() + 1000) t.add(Calendar.DAY_OF_MONTH, 1);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.getTimeInMillis(), p);
    }

    static void scheduleFast(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent p = pi(c, 99, "fast");
        SharedPreferences s = sp(c);
        long e = s.getLong("fastEnd", 0);
        if (!s.getBoolean("fast_on", true) || e <= System.currentTimeMillis()) { am.cancel(p); return; }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, e, p);
    }

    static void schedule(Context c) {
        for (int i = 0; i < IDS.length; i++) scheduleOne(c, i);
        scheduleFast(c);
    }
}
