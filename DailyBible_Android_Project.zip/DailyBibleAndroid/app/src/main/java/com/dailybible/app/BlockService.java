package com.dailybible.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.accessibility.AccessibilityEvent;
import java.util.Set;

public class BlockService extends AccessibilityService {
    private long last = 0;

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence pc = e.getPackageName();
        if (pc == null) return;
        SharedPreferences sp = Util.sp(this);
        if (!sp.getBoolean("lock", false)) return;
        if (Util.unlocked(this)) return;
        Set<String> blocked = sp.getStringSet("blocked", null);
        if (blocked == null || !blocked.contains(pc.toString())) return;
        long now = System.currentTimeMillis();
        if (now - last < 1200) return;
        last = now;
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("gate", true);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
    }

    @Override public void onInterrupt() { }
}
