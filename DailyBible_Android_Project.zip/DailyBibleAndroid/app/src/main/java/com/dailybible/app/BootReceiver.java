package com.dailybible.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

// Puts every reminder back after a restart, an app update, or a time or time zone change.
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String a = i == null ? null : i.getAction();
        boolean clockChange = "android.intent.action.TIME_SET".equals(a) || "android.intent.action.TIMEZONE_CHANGED".equals(a);
        try { Util.schedule(c, !clockChange); } catch (Exception e) { }
    }
}
