package com.dailybible.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

public class AppPickerActivity extends Activity {
    private final ArrayList<String> pk = new ArrayList<>(), lb = new ArrayList<>();
    private ListView lv;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF0B0A09);
        getWindow().setNavigationBarColor(0xFF0B0A09);
        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN);
        q.addCategory(Intent.CATEGORY_LAUNCHER);
        ArrayList<String[]> l = new ArrayList<>();
        HashSet<String> seen = new HashSet<>();
        for (ResolveInfo r : pm.queryIntentActivities(q, 0)) {
            String p = r.activityInfo.packageName;
            if (p.equals(getPackageName()) || !seen.add(p)) continue;
            l.add(new String[]{String.valueOf(r.loadLabel(pm)), p});
        }
        Collections.sort(l, new Comparator<String[]>() {
            @Override public int compare(String[] a, String[] c) { return a[0].compareToIgnoreCase(c[0]); }
        });
        for (String[] x : l) { lb.add(x[0]); pk.add(x[1]); }
        Set<String> sel = Util.sp(this).getStringSet("blocked", new HashSet<String>());

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0B0A09);
        root.setPadding(0, dp(24), 0, 0);
        TextView t = new TextView(this);
        t.setText("Choose apps to lock");
        t.setTextColor(0xFFECD69B);
        t.setTextSize(22);
        t.setPadding(dp(20), dp(8), dp(20), dp(4));
        root.addView(t);
        TextView s = new TextView(this);
        s.setText("These stay locked until you read today\u2019s verse.");
        s.setTextColor(0xFF8F8577);
        s.setTextSize(14);
        s.setPadding(dp(20), 0, dp(20), dp(12));
        root.addView(s);
        lv = new ListView(this);
        lv.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        lv.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, lb));
        for (int i = 0; i < pk.size(); i++) lv.setItemChecked(i, sel.contains(pk.get(i)));
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        Button d = new Button(this);
        d.setText("Done");
        d.setOnClickListener(v -> { save(); finish(); });
        root.addView(d);
        setContentView(root);
    }

    private void save() {
        if (lv == null) return;
        HashSet<String> out = new HashSet<>();
        for (int i = 0; i < pk.size(); i++) if (lv.isItemChecked(i)) out.add(pk.get(i));
        Util.sp(this).edit().putStringSet("blocked", out).apply();
    }

    @Override protected void onPause() { super.onPause(); save(); }
}
