package com.dailybible.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.util.Calendar;
import org.json.JSONArray;
import org.json.JSONObject;

// Home-screen widget showing the verse of the day. Reads the same list as the reminders.
public class VerseWidget extends AppWidgetProvider {
    static final String TICK = "com.dailybible.app.WIDGET_TICK";

    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { refresh(c); }

    @Override public void onEnabled(Context c) { refresh(c); }

    @Override public void onReceive(Context c, Intent in) {
        super.onReceive(c, in);
        if (in != null && TICK.equals(in.getAction())) refresh(c);
    }

    // Redraws every widget on the home screen and sets the next midnight refresh.
    static void refresh(Context c) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, VerseWidget.class));
            if (ids == null || ids.length == 0) return;

            String text = "Open Holy Steps to see today\u2019s verse.", ref = "";
            try {
                JSONArray a = new JSONArray(Util.sp(c).getString("verses", "[]"));
                long d = Util.day();
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    if (o.getLong("d") == d) { text = o.getString("t"); ref = o.getString("r"); break; }
                }
            } catch (Exception e) { }

            Intent open = new Intent(c, MainActivity.class);
            open.putExtra("go", "home");
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent tap = PendingIntent.getActivity(c, 61, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

            for (int id : ids) {
                RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_verse);
                v.setTextViewText(R.id.w_text, text);
                v.setTextViewText(R.id.w_ref, ref);
                v.setOnClickPendingIntent(R.id.w_root, tap);
                m.updateAppWidget(id, v);
            }
            scheduleTick(c);
        } catch (Exception e) { }
    }

    // New verse each day: refresh just after midnight.
    private static void scheduleTick(Context c) {
        Calendar t = Calendar.getInstance();
        t.add(Calendar.DAY_OF_MONTH, 1);
        t.set(Calendar.HOUR_OF_DAY, 0);
        t.set(Calendar.MINUTE, 1);
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        Intent i = new Intent(c, VerseWidget.class).setAction(TICK);
        PendingIntent p = PendingIntent.getBroadcast(c, 62, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Util.am(c).setAndAllowWhileIdle(AlarmManager.RTC, t.getTimeInMillis(), p);
    }
}
