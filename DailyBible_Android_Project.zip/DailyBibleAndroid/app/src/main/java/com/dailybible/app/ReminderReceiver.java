package com.dailybible.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String[] PRAYER = {
        "Pause and pray. God is listening.",
        "Bring today to God in prayer.",
        "Take a quiet minute to pray.",
        "Is there someone you can pray for today?"};
    private static final String[] MEMORY = {
        "Practice your memory verse. A few minutes is enough.",
        "Say your verse from memory today.",
        "Keep your verse fresh. Review it now.",
        "Hide it in your heart. Practice your verse."};
    private static final String[] REFLECT = {
        "How did you meet God today? Write a quick reflection.",
        "Look back on your day. Where did you see God?",
        "End the day with a short reflection.",
        "Take a minute to write what you are thankful for."};

    @Override public void onReceive(Context c, Intent in) {
        String id = in.getStringExtra("id");
        if (id == null) return;
        SharedPreferences sp = Util.sp(c);
        boolean once = in.getBooleanExtra("once", false);
        int idx = -1;
        for (int i = 0; i < Util.IDS.length; i++) if (Util.IDS[i].equals(id)) idx = i;
        int nid = idx >= 0 ? 10 + idx : 99;

        if (in.getBooleanExtra("snooze", false)) {
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(nid);
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 10 * 60000L, Util.pi(c, 200 + nid, id, true, false));
            return;
        }

        String title = "Holy Steps", text = null, go = "home";
        int k = (int) (Util.day() % 4);

        if (id.equals("fast")) {
            if (sp.getBoolean("fast_on", true) || once) {
                title = "Fast complete";
                text = "Well done. Thank God, and break your fast gently.";
                go = "fast";
            }
            if (!once) sp.edit().putLong("fastEnd", 0).apply();
        } else if (idx >= 0 && (Util.on(c, id) || once)) {
            switch (id) {
                case "verse":
                    text = "Take a moment with God\u2019s Word today.";
                    try {
                        JSONArray a = new JSONArray(sp.getString("verses", "[]"));
                        long d = Util.day();
                        for (int i = 0; i < a.length(); i++) {
                            JSONObject o = a.getJSONObject(i);
                            if (o.getLong("d") == d) { text = o.getString("t"); title = o.getString("r"); break; }
                        }
                    } catch (Exception e) { }
                    break;
                case "plan": {
                    title = "Reading plan";
                    String pt = sp.getString("planText", "");
                    if (!pt.isEmpty()) text = "Today\u2019s reading: " + pt;   // no plan started = no reminder
                    go = "plan";
                    break;
                }
                case "prayer": title = "Prayer time"; text = PRAYER[k]; go = "prayer"; break;
                case "memory": title = "Verse practice"; text = MEMORY[k]; go = "memory"; break;
                case "reflect": title = "Evening reflection"; text = REFLECT[k]; go = "reflect"; break;
                case "streak":
                    title = "Keep your streak";
                    // Only remind if today's verse has not been read yet.
                    if (sp.getLong("read", -1) != Util.day()) text = "Read today\u2019s verse and keep your steps going.";
                    break;
                default: break;
            }
            // Don't nag if it is already done today.
            if (!id.equals("verse") && !id.equals("streak") && Util.done(c, id)) text = null;
            if (!once) Util.scheduleOne(c, idx);
        }

        if (text != null) show(c, title, text, go, nid, Util.alarm(c, id), id);
    }

    static void show(Context c, String title, String text, String go, int nid, boolean alarm, String id) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("reminders", "Reminders", NotificationManager.IMPORTANCE_DEFAULT));
        if (alarm) {
            NotificationChannel ac = new NotificationChannel("alarms", "Alarm reminders", NotificationManager.IMPORTANCE_HIGH);
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            ac.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), aa);
            ac.enableVibration(true);
            ac.setVibrationPattern(new long[]{0, 600, 300, 600});
            nm.createNotificationChannel(ac);
        }
        Intent open = new Intent(c, MainActivity.class);
        open.putExtra("go", go);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(c, 20 + nid, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = new Notification.Builder(c, alarm ? "alarms" : "reminders")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setAutoCancel(true);
        if (alarm) {
            b.setCategory(Notification.CATEGORY_ALARM).setTimeoutAfter(60000);
            b.addAction(new Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_stat), "Snooze 10 min",
                    Util.pi(c, 300 + nid, id, false, true)).build());
        }
        Notification n = b.build();
        if (alarm) n.flags |= Notification.FLAG_INSISTENT;   // keeps ringing until you tap, swipe or snooze (max 1 minute)
        nm.notify(nid, n);
    }
}
