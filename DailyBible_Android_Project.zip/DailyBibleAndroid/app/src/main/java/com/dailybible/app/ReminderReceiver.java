package com.dailybible.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String[] PRAYER = {
        "Pause and pray. God is listening.",
        "Bring today to God in prayer.",
        "Take a quiet minute to pray.",
        "Is there someone you can pray for today?"};
    private static final String[] MEMORY = {
        "Practice your memory verse. A few minutes is enough.",
        "Say your verse from memory today.",
        "Keep your verse fresh. Review it now.",
        "Hide it in your heart. Practice your verse."};
    private static final String[] REFLECT = {
        "How did you meet God today? Write a quick reflection.",
        "Look back on your day. Where did you see God?",
        "End the day with a short reflection.",
        "Take a minute to write what you are thankful for."};

    private static final int MAX_NAGS = 8;   // keep-reminding stops after 8 repeats (4 hours)

    @Override public void onReceive(Context c, Intent in) {
        String id = in.getStringExtra("id");
        if (id == null) return;
        try { handle(c, id, in.getIntExtra("mode", Util.M_DAILY)); } catch (Exception e) { }
    }

    private void handle(Context c, String id, int mode) {
        SharedPreferences sp = Util.sp(c);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        int idx = Util.idx(id), nid = Util.nid(id);

        // You tapped Snooze: clear the notification and ring again in 10 minutes. No limit on snoozes.
        if (mode == Util.M_SNOOZE) {
            nm.cancel(nid);
            Util.followUp(c, id, Util.M_AGAIN, System.currentTimeMillis() + Util.SNOOZE_MS);
            return;
        }

        boolean follow = mode == Util.M_AGAIN || mode == Util.M_NAG;
        if (follow) {
            Util.clearFollowUp(c, id);
        } else if (idx >= 0) {
            // Set up tomorrow FIRST, so a problem below can never break the daily chain.
            Util.scheduleOne(c, idx);
            Util.cancelFollowUp(c, id);
            sp.edit().putLong("last_" + id, Util.day()).putInt("nagn_" + id, 0).apply();
        }

        String title = "Holy Steps", text = null, go = "home";
        int k = (int) (Util.day() % 4);

        if (id.equals("fast")) {
            if (sp.getBoolean("fast_on", true) || follow) {
                title = "Fast complete";
                text = "Well done. Thank God, and break your fast gently.";
                go = "fast";
            }
            if (!follow) sp.edit().putLong("fastEnd", 0).apply();
        } else if (idx >= 0 && (Util.on(c, id) || mode == Util.M_AGAIN)) {
            switch (id) {
                case "verse":
                    text = "Take a moment with God\u2019s Word today.";
                    try {
                        JSONArray a = new JSONArray(sp.getString("verses", "[]"));
                        long d = Util.day();
                        for (int i = 0; i < a.length(); i++) {
                            JSONObject o = a.getJSONObject(i);
                            if (o.getLong("d") == d) { text = o.getString("t"); title = o.getString("r"); break; }
                        }
                    } catch (Exception e) { }
                    break;
                case "plan": {
                    title = "Reading plan";
                    String pt = sp.getString("planText", "");
                    if (!pt.isEmpty()) text = "Today\u2019s reading: " + pt;   // no plan started = no reminder
                    go = "plan";
                    break;
                }
                case "prayer": title = "Prayer time"; text = PRAYER[k]; go = "prayer"; break;
                case "memory": title = "Verse practice"; text = MEMORY[k]; go = "memory"; break;
                case "reflect": title = "Evening reflection"; text = REFLECT[k]; go = "reflect"; break;
                case "streak":
                    title = "Keep your streak";
                    // Only remind if today's verse has not been read yet.
                    if (sp.getLong("read", -1) != Util.day()) text = "Read today\u2019s verse and keep your steps going.";
                    break;
                default: break;
            }
            // Don't nag if it is already done today.
            if (!id.equals("verse") && !id.equals("streak") && Util.done(c, id)) text = null;
        }

        // Is today's task finished? Then snoozes and repeats stop.
        boolean finished = idx >= 0 && (id.equals("streak") ? sp.getLong("read", -1) == Util.day() : Util.done(c, id));
        if (follow && finished) text = null;
        if (text == null) return;

        show(c, title, text, go, nid, Util.alarm(c, id), id);

        // Keep reminding: ring again in 30 minutes until it is done (max 8 repeats).
        if (idx >= 0 && !finished && Util.on(c, id) && sp.getBoolean("nag_on", true)) {
            int n = sp.getInt("nagn_" + id, 0);
            if (mode == Util.M_NAG) { n++; sp.edit().putInt("nagn_" + id, n).apply(); }
            if (n < MAX_NAGS) Util.followUp(c, id, Util.M_NAG, System.currentTimeMillis() + Util.NAG_MS);
        }
    }

    static void show(Context c, String title, String text, String go, int nid, boolean alarm, String id) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("reminders", "Reminders", NotificationManager.IMPORTANCE_DEFAULT));
        if (alarm) {
            NotificationChannel ac = new NotificationChannel("alarms", "Alarm reminders", NotificationManager.IMPORTANCE_HIGH);
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            ac.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), aa);
            ac.enableVibration(true);
            ac.setVibrationPattern(new long[]{0, 600, 300, 600});
            nm.createNotificationChannel(ac);
        }
        Intent open = new Intent(c, MainActivity.class);
        open.putExtra("go", go);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(c, 20 + nid, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = new Notification.Builder(c, alarm ? "alarms" : "reminders")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setAutoCancel(true);
        if (alarm) {
            b.setCategory(Notification.CATEGORY_ALARM).setTimeoutAfter(60000);
            b.addAction(new Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_stat), "Snooze 10 min",
                    Util.pi(c, 300 + nid, id, Util.M_SNOOZE)).build());
        }
        Notification n = b.build();
        if (alarm) n.flags |= Notification.FLAG_INSISTENT;   // keeps ringing until you tap, swipe or snooze (max 1 minute)
        nm.notify(nid, n);
    }
}
