HOLY STEPS - ANDROID APP

Build the APK in the cloud (free, about 5 minutes):
1. Make a free account at github.com and create a new repository (private is fine).
2. Upload EVERYTHING in this folder to it, including the hidden .github folder.
   If .github will not upload: tap Add file > Create new file, type
   .github/workflows/build.yml and paste the text of build.yml from this folder.
3. Open the Actions tab > Build APK > Run workflow. Wait for the green tick.
4. Open the finished run, download "DailyBible-APK", unzip it, install app-debug.apk.
   (Allow "Install unknown apps" for your browser or Files app when asked.)

After installing, for the verse lock on Android 13 or newer:
Settings > Apps > Daily Bible > three dots (top right) > Allow restricted settings.
Then in the app: Grow > Settings > choose apps > Lock On > Open Accessibility settings > Daily Bible > turn on.
