HOLY STEPS WEBSITE
==================
Files: index.html (landing page), app.html (installable web app), manifest.json, sw.js, icons, logo.jpg

1) BUILD THE APK  (Android Studio, with the DailyBible_Android_Project)
   Build > Build Bundle(s)/APK(s) > Build APK(s)
   Find it in app/build/outputs/apk/ and rename it to:  HolySteps.apk
2) PUT HolySteps.apk IN THIS FOLDER (next to index.html). The Download button points to it.
3) HOST THE FOLDER (free): Netlify Drop (drag the folder in), GitHub Pages, or Cloudflare Pages. HTTPS is required for the web app install.

Notes: Reminders/alarms only work in the Android app. The web app is for reading, prayer, challenges, journal.
For public release use a SIGNED release APK (Build > Generate Signed Bundle/APK).
